use mico-services, split up the services into multi servers.
Servers can perform the same function but in differnt hardwares or vitual servers such as docker.
The server can located in differnt GEO locations.
Use Nginx and round robin, to route the request to differnt servers.
