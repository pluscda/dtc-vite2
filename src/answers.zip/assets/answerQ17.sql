inner join:
will show the rows that exist in both tables; which is 1 ,2, 3

right join:
1, 3, 4,5 total is 4 rows

