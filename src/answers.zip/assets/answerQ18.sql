index:
domain_id, publisher_id

