<template>
  <section>
    <header class="flex justify-around mb-4">
      <div>....</div>
      <div>...</div>
      <div>...</div>
    </header>

    <h4>Details about the Item</h4>
    <p>A limited....</p>
  </section>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {},
};
</script>

<style></style>
