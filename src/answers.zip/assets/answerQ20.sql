1. use Elasticsearch + Kibana to find out which end point is possible bottleneck.

2. Install monitor/watch dog service to see which process(maby be OS level or api level) or api(3rd party included)  the issue.


3. Add X-Response-Time header to find out which API reponse slow and try to fix it.
  
