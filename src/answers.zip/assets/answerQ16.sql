Dashboard for Web Ower:

1. Have Nav bar in top or left, and first item in nav bar is "Dashboard"
    * show 12 months registerd users using bar chart.
    * Top 10 customers that posted most this month.
    * Top 10 most favorites site that user like to save as their folders.
    * Show top 10 mosted people views in our website.
2. User Managemnt below / rightside of  the Dashboard menu.
    * Create / Delete / Read / Update User.
    * set black list for users.
    * upload size for each users.
    
3. User Favorites Managemnt
    * folders number upper limit for whole site or for each user.
    * set black list for favorites list.
    * Create / Delete / Read / Update Favorites